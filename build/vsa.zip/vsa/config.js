window.Config = {
	BASE_URL: 'http://localhost:8079/vote_sorocaba/api',
	CADASTRO_URL: 'http://localhost:8079/vote_sorocaba/api',
	ENV: 'AMBIENTE DE TESTES',
	CODIGO_SOROCABA: 9696,
	ID_TIPO_RENDA_SEM_RENDA: 1,
	ID_TIPO_RISCO_SEM_RISCO: 1,
	ID_SEM_DEFICIENCIA: 1
};